import csv, json, os, time, urllib.request
from datetime import datetime, timezone
from pathlib import Path

# DEMO SCANNER ONLY: public market data; no orders, transfers, or private keys.
STARTING_BALANCE = float(os.getenv("STARTING_BALANCE", "200"))
RUNTIME_MINUTES = int(os.getenv("BOT_RUNTIME_MINUTES", "30"))
POLL_SECONDS = max(5, int(os.getenv("POLL_SECONDS", "15")))
MIN_SPREAD_PCT = float(os.getenv("MIN_SPREAD_PCT", "0.30"))
PAIRS = [("BTCUSDT", "BTC-USD", "BTC"), ("ETHUSDT", "ETH-USD", "ETH"), ("SOLUSDT", "SOL-USD", "SOL")]

def get_json(url, timeout=12):
    req = urllib.request.Request(url, headers={"User-Agent": "CryptoArbitrageDemo/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())

def book(url):
    data = get_json(url)
    return ([(float(p), float(q)) for p, q in data.get("bids", [])],
            [(float(p), float(q)) for p, q in data.get("asks", [])])

def vwap(levels, qty):
    remaining, cost, filled = qty, 0.0, 0.0
    for price, avail in levels:
        take = min(remaining, avail)
        cost += take * price
        filled += take
        remaining -= take
        if remaining <= 1e-12:
            break
    return cost / filled if remaining <= 1e-12 and filled else None

def scan():
    rows = []
    for b_symbol, c_product, coin in PAIRS:
        try:
            b_bids, b_asks = book(f"https://api.binance.com/api/v3/depth?symbol={b_symbol}&limit=20")
            c_bids, c_asks = book(f"https://api.exchange.coinbase.com/products/{c_product}/book?level=2")
            b_ask = b_asks[0][0] if b_asks else 0
            c_ask = c_asks[0][0] if c_asks else 0
            if not b_ask or not c_ask:
                continue
            qty = 25.0 / max(b_ask, c_ask)
            bb, bs = vwap(b_bids, qty), vwap(b_asks, qty)
            cb, cs = vwap(c_bids, qty), vwap(c_asks, qty)
            if None in (bb, bs, cb, cs):
                continue
            # Illustrative 0.10% taker fee per side; not your actual fee tier.
            fee = 0.001
            # USDT is treated as roughly USD; basis risk is not modeled.
            edge_b_to_c = (cs * (1-fee) - bs * (1+fee)) / bs * 100
            edge_c_to_b = (bb * (1-fee) - cb * (1+fee)) / cb * 100
            rows.append({
                "time_utc": datetime.now(timezone.utc).isoformat(), "coin": coin,
                "reference_notional_usd": 25,
                "binance_buy_vwap": round(bs, 8), "binance_sell_vwap": round(bb, 8),
                "coinbase_buy_vwap": round(cs, 8), "coinbase_sell_vwap": round(cb, 8),
                "estimated_edge_binance_to_coinbase_pct": round(edge_b_to_c, 5),
                "estimated_edge_coinbase_to_binance_pct": round(edge_c_to_b, 5),
                "note": "Screening estimate only; excludes transfers, exact fees, USDT/USD basis and execution risk."
            })
        except Exception as e:
            print(f"[WARN] {coin}: market data unavailable: {e}")
    return rows

def main():
    print("CRYPTO ARBITRAGE DEMO — SCANNER ONLY, NO REAL ORDERS")
    print(f"Simulated balance ${STARTING_BALANCE:.2f}; runtime {RUNTIME_MINUTES} min; polling every {POLL_SECONDS}s")
    print("Sources: public Binance and Coinbase spot order books; pairs BTC, ETH, SOL.")
    fields = ["time_utc","coin","reference_notional_usd","binance_buy_vwap","binance_sell_vwap",
              "coinbase_buy_vwap","coinbase_sell_vwap","estimated_edge_binance_to_coinbase_pct",
              "estimated_edge_coinbase_to_binance_pct","note"]
    best = None
    snapshots = empty_cycles = 0
    end = time.monotonic() + max(1, RUNTIME_MINUTES) * 60
    with open("opportunities.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        while time.monotonic() < end:
            rows = scan()
            if not rows:
                empty_cycles += 1
            for row in rows:
                writer.writerow(row); f.flush(); snapshots += 1
                for edge_key, direction in [
                    ("estimated_edge_binance_to_coinbase_pct","Binance → Coinbase"),
                    ("estimated_edge_coinbase_to_binance_pct","Coinbase → Binance")]:
                    edge = row[edge_key]
                    if best is None or edge > best["edge"]:
                        best = {"edge": edge, "coin": row["coin"], "direction": direction}
                    if edge >= MIN_SPREAD_PCT:
                        print(f"[POTENTIAL] {row['coin']} {direction}: estimated edge {edge:.3f}% (not guaranteed executable)")
            print(f"[{datetime.now(timezone.utc).strftime('%H:%M:%S UTC')}] snapshots={snapshots}; empty/error cycles={empty_cycles}")
            time.sleep(POLL_SECONDS)
    report = [
        "CRYPTO ARBITRAGE DEMO REPORT",
        f"Simulated starting balance: ${STARTING_BALANCE:.2f}",
        f"Order-book snapshots recorded: {snapshots}",
        f"Empty/error scan cycles: {empty_cycles}",
        "Real orders placed: NO",
        "Real funds transferred: NO",
        "Realized profit: $0.00 (scanner only; no trades executed)",
        f"Best observed estimated edge: {best['edge']:.5f}% for {best['coin']} {best['direction']}" if best else "Best observed estimated edge: unavailable",
        "This is a screening scanner, not an execution bot. Estimated spreads are not guaranteed profit.",
        "Illustrative 0.10% fee per side only. Excludes exact account fees, transfers, inventory/rebalancing, latency, USDT/USD basis and execution failures."
    ]
    Path("demo_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n" + "\n".join(report))

if __name__ == "__main__":
    main()
