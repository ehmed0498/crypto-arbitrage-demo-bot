# Crypto Arbitrage Demo Scanner

**Scanner only: no live orders, no transfers, no API keys or wallet secrets.**

- Compares public Binance and Coinbase spot order books for BTC, ETH and SOL.
- Estimates small-notional VWAP spreads using an illustrative fee assumption.
- Records observations in `opportunities.csv` and writes `demo_report.txt`.
- Runs through GitHub Actions for 30 minutes by default.

## Important limitations
This is not an execution bot and does not prove profitability. USDT is treated as approximately USD, and actual fees may differ. Transfers, inventory/rebalancing costs, network fees, regional availability, latency and execution failures are not modeled. Verify market access and compliance before considering any real trading.
